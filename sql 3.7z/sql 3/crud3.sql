CREATE TABLE Titulada(
id INT (20) UNIQUE PRIMARY KEY,
nombre_apellido VARCHAR (50) UNIQUE NOT NULL,
correo VARCHAR(50) UNIQUE NOT NULL,
edad INT UNSIGNED NOT NULL,
direccion VARCHAR(20) NOT NULL,
ciudad VARCHAR(20) NOT NULL,
estado ENUM('Activo', 'Inactivo') DEFAULT 'Inactivo',
formación ENUM('Técnico', 'Tecnólogo') DEFAULT 'Tecnólogo',
creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO Titulada (id, nombre_apellido, correo, edad,
direccion, ciudad, estado, formación)


INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (58943, 'Juan Pérez', 'juanperez@example.com', 25, 'Calle Principal 123', 'Ciudad A', 'Activo', 'Tecnólogo');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (72910, 'María Gómez', 'mariagomez@example.com', 30, 'Avenida Central 456', 'Ciudad B', 'Inactivo', 'Técnico');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (84576, 'Carlos López', 'carloslopez@example.com', 28, 'Calle Secundaria 789', 'Ciudad A', 'Activo', 'Tecnólogo');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (36215, 'Ana Rodríguez', 'anarodriguez@example.com', 32, 'Avenida Principal 987', 'Ciudad C', 'Inactivo', 'Técnico');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (48179, 'Pedro Mendoza', 'pedromendoza@example.com', 27, 'Calle Central 654', 'Ciudad B', 'Activo', 'Tecnólogo');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (93568, 'Laura Torres', 'latorres@example.com', 29, 'Avenida Secundaria 321', 'Ciudad A', 'Inactivo', 'Técnico');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (25436, 'Miguel Sánchez', 'miguelsanchez@example.com', 31, 'Calle Principal 654', 'Ciudad C', 'Activo', 'Tecnólogo');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (70582, 'Isabel García', 'isabelgarcia@example.com', 26, 'Avenida Central 987', 'Ciudad A', 'Inactivo', 'Técnico');
INSERT INTO Titulada (id, nombre_apellido, correo, edad, direccion, ciudad, estado, formación) VALUES (19647, 'Luisa Martínez', 'luisamartinez@example.com', 33, 'Calle Secundaria 321', 'Ciudad B', 'Activo', 'Tecnólogo');
INSERT INTO Titulada (id, nomb



CREATE DATABASE FACTURACION;
USE FACTURACION;

CREATE TABLE CLIENTE(
    id_cliente VARCHAR(30) UNIQUE PRIMARY KEY,
    nombre VARCHAR (25) UNIQUE NOT NULL,
    apellido VARCHAR (25) UNIQUE NOT NULL,
    direccion VARCHAR (20) NOT NULL,
    telefono VARCHAR (20) NOT NULL,
    correo VARCHAR (50)  UNIQUE NOT NULL,
    municipio VARCHAR(20),
    departamento VARCHAR (20),
    pais VARCHAR (20) CHECK (pais='Colombia'),
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
);

CREATE TABLE factura(
    num_factura VARCHAR (20) UNIQUE PRIMARY KEY,
    id_cliente VARCHAR (30),
    id_producto VARCHAR(30),
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto)

);

CREATE TABLE productos(
    id_producto VARCHAR (30) UNIQUE PRIMARY KEY,
    nombre VARCHAR (25) NOT NULL,
    precio INT (25) NOT NULL,
    stock INT (25) not NULL,
    num_factura VARCHAR (20),
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (num_factura) REFERENCES factura(num_factura)

);

